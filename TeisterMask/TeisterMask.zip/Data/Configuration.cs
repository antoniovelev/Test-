﻿namespace TeisterMask.Data
{
    public static class Configuration
    {
        public static string ConnectionString = @"Server=DESKTOP-M0V234P\SQLEXPRESS01;Database=TeisterMask;Trusted_Connection=True";
    }
}
